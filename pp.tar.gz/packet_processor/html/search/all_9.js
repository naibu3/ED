var searchData=
[
  ['next_20',['next',['../classSNode.html#ac6791c141a15f5c71b326587e4ef8b2b',1,'SNode::next()'],['../classSList.html#a30815e0a46eb7de7ebb2e5c1e2fc97f1',1,'SList::next()']]]
];
