var indexSectionsWithContent =
{
  0: "_bcdefghinpqrst~",
  1: "pqrs",
  2: "bcdefghinpqrst~",
  3: "_",
  4: "r",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Pages"
};

